class Cell:

  def __init__(self, alive):
    self.alive = alive
    
  def setAlive(self, tf):
    self.alive = tf
    
  def isAlive(self):
    return self.alive