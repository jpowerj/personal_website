import util

# life.py
# Jeff Jacobs, CS221

class Life:
  
  # THE RULES:
  #
  # Any live cell with fewer than two live neighbours dies, as if caused by under-population.
  # Any live cell with two or three live neighbours lives on to the next generation.
  # Any live cell with more than three live neighbours dies, as if by overcrowding.
  # Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.

  def __init__(self, board):
    self.rows = len(board)
    self.cols = len(board[0])
    self.grid = board
    
  def isAlive(self, row, col):
    return self.grid[row][col]['alive']
  
  def setAlive(self, row, col, tf):
    self.grid[row][col]['alive'] = tf
    
  def getNumRows(self):
    return self.rows
    
  def getNumCols(self):
    return self.cols
    
  def runTimeStep(self):
    newGrid = util.createEmptyGrid(self.getNumRows(), self.getNumCols())
    for i in range(self.getNumRows()):
      for j in range(self.getNumCols()):
        numLiveNeighbors = util.getNumLiveNeighbors(self,i,j)
        if self.isAlive(i,j) and numLiveNeighbors < 2:
          newGrid[i][j]['alive'] = False
        if self.isAlive(i,j) and (numLiveNeighbors == 2 or numLiveNeighbors == 3):
          newGrid[i][j]['alive'] = True
        if self.isAlive(i,j) and numLiveNeighbors > 3:
          newGrid[i][j]['alive'] = False
        if (not self.isAlive(i,j)) and numLiveNeighbors == 3:
          newGrid[i][j]['alive'] = True
        if (not self.isAlive(i,j)) and numLiveNeighbors != 3:
          newGrid[i][j]['alive'] = False
    self.grid = newGrid
